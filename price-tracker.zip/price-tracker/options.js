document.getElementById('saveSettings').addEventListener('click', function() {
    const notificationType = document.getElementById('notificationType').value;

    chrome.storage.local.set({ notificationType }, function() {
        document.getElementById('message').textContent = 'Settings saved!';
    });
});

// Load existing settings
chrome.storage.local.get(['notificationType'], function(data) {
    if (data.notificationType) {
        document.getElementById('notificationType').value = data.notificationType;
    }
}); 