console.log("Content script loaded and running!");

const getPrice = () => {
    console.log("Starting price extraction...");

    // Helper function to parse price in various formats including Greek locale
    const parseLocalePrice = (priceStr) => {
        if (typeof priceStr !== 'string') {
            priceStr = String(priceStr);
        }
        
        // Remove any currency symbols and whitespace
        priceStr = priceStr.replace(/[^\d,.-]/g, '').trim();
        
        // Check if it's in Greek format (1.234,56)
        if (priceStr.includes('.') && priceStr.includes(',')) {
            // Remove thousand separators and replace decimal comma with dot
            return parseFloat(priceStr.replace(/\./g, '').replace(',', '.'));
        }
        
        // Handle comma as decimal separator
        if (priceStr.includes(',') && !priceStr.includes('.')) {
            return parseFloat(priceStr.replace(',', '.'));
        }
        
        return parseFloat(priceStr);
    };

    // Helper function to extract currency and price
    const extractPriceAndCurrency = (priceStr) => {
        const currencySymbols = {
            '$': '$',
            '€': '€',
            '£': '£',
            '¥': '¥',
            '₹': '₹'
        };

        // Find currency symbol
        let currencySymbol = '$'; // Default
        for (const symbol of Object.keys(currencySymbols)) {
            if (priceStr.includes(symbol)) {
                currencySymbol = symbol;
                break;
            }
        }

        // Extract price value using locale-aware parsing
        const price = parseLocalePrice(priceStr);
        console.log('Extracted price:', { original: priceStr, parsed: price });
        return !isNaN(price) && price > 0 ? { price, currency: currencySymbol } : null;
    };

    // Function to extract product title
    function getProductTitle() {
        // Try meta tags first
        const metaTitleSelectors = [
            'meta[property="og:title"]',
            'meta[name="title"]',
            'meta[property="product:title"]',
            'meta[itemprop="name"]'
        ];

        for (const selector of metaTitleSelectors) {
            const meta = document.querySelector(selector);
            if (meta) {
                const content = meta.getAttribute('content');
                if (content) return content.trim();
            }
        }

        // Try common product title selectors
        const titleSelectors = [
            'h1[itemprop="name"]',
            'h1.product-title',
            'h1.product-name',
            'h1.product_title',
            'h1.title',
            '#productTitle',
            '.product-title',
            '.product-name',
            'h1:first-of-type'  // fallback to first h1
        ];

        for (const selector of titleSelectors) {
            const element = document.querySelector(selector);
            if (element) {
                const text = element.textContent;
                if (text) return text.trim();
            }
        }

        // Fallback to page title
        const pageTitle = document.title;
        if (pageTitle) {
            // Remove common site names and separators from title
            return pageTitle.split(/[|\-–—]/).map(s => s.trim())[0];
        }

        return null;
    }

    // First try meta tags with sale/discount price
    const salePriceMetaSelectors = [
        'meta[property*="sale_price"]',
        'meta[property*="discounted_price"]',
        'meta[property*="offer_price"]',
        'meta[property*="price:amount"]',
        'meta[property*="og:price"]'
    ];

    // Try to get currency from meta tags first
    const currencyMeta = document.querySelector('meta[property*="currency"], meta[itemprop*="currency"]');
    let defaultCurrency = currencyMeta ? currencyMeta.getAttribute('content') : null;
    if (defaultCurrency === 'EUR') defaultCurrency = '€';
    if (defaultCurrency === 'USD') defaultCurrency = '$';
    if (defaultCurrency === 'GBP') defaultCurrency = '£';

    console.log("Checking meta tags for sale prices...");
    for (const selector of salePriceMetaSelectors) {
        const meta = document.querySelector(selector);
        if (meta) {
            const content = meta.getAttribute('content');
            console.log(`Found meta price (${selector}):`, content);
            const priceData = extractPriceAndCurrency(content);
            if (priceData !== null) {
                // If we found a currency in meta tags, use it
                if (defaultCurrency) {
                    priceData.currency = defaultCurrency;
                }
                console.log("Found valid sale price in meta tag:", priceData);
                return {
                    priceData: priceData,
                    title: getProductTitle()
                };
            }
        }
    }

    // Try structured data (JSON-LD)
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    console.log("Found JSON-LD scripts:", scripts.length);
    for (const script of scripts) {
        try {
            const data = JSON.parse(script.textContent);
            console.log("Parsed JSON-LD data:", data);
            
            // Function to recursively search for price in object
            const findPrice = (obj) => {
                if (!obj) return null;
                if (typeof obj === 'object') {
                    // Check for currency first
                    let currency = obj.priceCurrency || defaultCurrency;
                    if (currency === 'EUR') currency = '€';
                    if (currency === 'USD') currency = '$';
                    if (currency === 'GBP') currency = '£';

                    // First check for offer/sale prices
                    const priceKeys = [
                        'offers.price',
                        'offers.lowPrice',
                        'offers.salePrice',
                        'offers.discountPrice',
                        'offer.price',
                        'offer.salePrice',
                        'price',
                        'salePrice',
                        'lowPrice',
                        'discountPrice'
                    ];

                    // Helper to get nested property
                    const getNestedValue = (obj, path) => {
                        return path.split('.').reduce((prev, curr) => 
                            prev && prev[curr], obj);
                    };

                    // Check each price key
                    for (const key of priceKeys) {
                        const value = getNestedValue(obj, key);
                        if (typeof value === 'string' || typeof value === 'number') {
                            const priceData = extractPriceAndCurrency(String(value));
                            if (priceData !== null) {
                                if (currency) {
                                    priceData.currency = currency;
                                }
                                console.log(`Found price in JSON-LD (${key}):`, priceData);
                                return {
                                    priceData: priceData,
                                    title: getProductTitle()
                                };
                            }
                        }
                    }

                    // Recursively check all properties
                    for (const key in obj) {
                        if (typeof obj[key] === 'object') {
                            const result = findPrice(obj[key]);
                            if (result !== null) return result;
                        }
                    }
                }
                return null;
            };

            const priceData = findPrice(data);
            if (priceData !== null) return priceData;

        } catch (e) {
            console.log("Error parsing JSON-LD:", e);
        }
    }

    // Try common sale price selectors
    const salePriceSelectors = [
        '[data-price-type="finalPrice"]',
        '[data-price-type="salePrice"]',
        '[data-price-type="specialPrice"]',
        '.sale-price',
        '.special-price',
        '.discount-price',
        '.current-price',
        '.now-price',
        '[class*="sale-price"]',
        '[class*="special-price"]',
        '[class*="current-price"]',
        '[class*="price--sale"]',
        '[data-price]',
        '[data-product-price]',
        '.price',
        '.product-price',
        '.offer-price',
        '#priceblock_ourprice',
        '.a-price',
        '[itemprop="price"]'
    ];

    console.log("Trying sale price selectors...");
    for (const selector of salePriceSelectors) {
        try {
            const elements = document.querySelectorAll(selector);
            console.log(`Found ${elements.length} elements for selector: ${selector}`);
            
            for (const element of elements) {
                // Skip if element contains "regular", "old", or "was" price indicators
                const elementText = element.textContent.toLowerCase();
                if (elementText.match(/regular|original|old|was|rrp|mrp/)) {
                    console.log('Skipping element with regular/old price indicator:', elementText);
                    continue;
                }

                // Get both text content and any price-related attributes
                const textContent = element.textContent;
                const priceAttrs = ['data-price', 'data-product-price', 'content'];
                
                console.log(`Element content for ${selector}:`, {
                    text: textContent,
                    html: element.innerHTML,
                    attributes: Array.from(element.attributes).map(attr => `${attr.name}="${attr.value}"`)
                });

                // Check attributes first
                for (const attr of priceAttrs) {
                    const attrValue = element.getAttribute(attr);
                    if (attrValue) {
                        const priceData = extractPriceAndCurrency(attrValue);
                        if (priceData !== null) {
                            console.log(`Found valid price in attribute ${attr}:`, priceData);
                            return {
                                priceData: priceData,
                                title: getProductTitle()
                            };
                        }
                    }
                }

                // Then check text content
                if (textContent) {
                    const priceData = extractPriceAndCurrency(textContent);
                    if (priceData !== null) {
                        console.log("Found valid price in text content:", priceData);
                        return {
                            priceData: priceData,
                            title: getProductTitle()
                        };
                    }
                }
            }
        } catch (e) {
            console.log("Error processing selector:", selector, e);
        }
    }

    // As a last resort, search all text nodes for price patterns
    console.log("Searching all text nodes...");
    const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT,
        null,
        false
    );

    const prices = [];
    while (walker.nextNode()) {
        const node = walker.currentNode;
        const text = node.textContent.trim();
        
        if (text) {
            // Skip if node contains "regular", "old", or "was" price indicators
            if (text.toLowerCase().match(/regular|original|old|was|rrp|mrp/)) {
                continue;
            }

            console.log("Checking text node:", text);
            const priceData = extractPriceAndCurrency(text);
            if (priceData !== null) {
                console.log("Found valid price in text node:", priceData);
                prices.push(priceData);
            }
        }
    }

    // Return the lowest price found (likely the sale price)
    if (prices.length > 0) {
        const lowestPrice = prices.reduce((min, current) => 
            current.price < min.price ? current : min
        );
        console.log("Using lowest price found:", lowestPrice);
        return {
            priceData: lowestPrice,
            title: getProductTitle()
        };
    }

    console.log("No valid price found on the page");
    return null;
};

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Content script received message:', request);
    if (request.action === "getPrice") {
        const result = getPrice();
        console.log('Sending back result:', result);
        sendResponse(result);
    }
});

// Log that we're ready
console.log("Content script fully loaded and ready to extract prices!");