// Function to parse price from various formats including Greek locale
function parseLocalePrice(priceStr) {
    if (typeof priceStr !== 'string') {
        return priceStr;
    }
    
    // Remove any currency symbols and whitespace
    priceStr = priceStr.replace(/[^\d,.-]/g, '').trim();
    
    // Check if it's in Greek format (1.234,56)
    if (priceStr.includes('.') && priceStr.includes(',')) {
        // Remove thousand separators and replace decimal comma with dot
        return parseFloat(priceStr.replace(/\./g, '').replace(',', '.'));
    }
    
    // Handle comma as decimal separator
    if (priceStr.includes(',') && !priceStr.includes('.')) {
        return parseFloat(priceStr.replace(',', '.'));
    }
    
    return parseFloat(priceStr);
}

// Function to format price nicely
function formatPrice(priceData) {
    if (!priceData) return 'N/A';
    
    if (typeof priceData === 'object') {
        // Handle price data object with currency
        const price = parseLocalePrice(priceData.price);
        if (isNaN(price)) return 'N/A';
        
        // Format with Greek locale
        const formattedPrice = new Intl.NumberFormat('el-GR', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(price);
        
        return `${priceData.currency}${formattedPrice}`;
    }
    
    // Fallback for legacy data or when only price is provided
    const price = parseLocalePrice(priceData);
    if (isNaN(price)) return 'N/A';
    
    // Format with Greek locale and use Euro as default
    const formattedPrice = new Intl.NumberFormat('el-GR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(price);
    
    return `€${formattedPrice}`;
}

let cachedProducts = [];
let productElements = new Map();

// Function to update the product list display
async function updateProductList(searchQuery = '') {
    const productList = document.getElementById('productList');
    
    try {
        // Only fetch products from storage if we don't have them cached
        if (cachedProducts.length === 0) {
            const data = await chrome.storage.local.get(['products']);
            cachedProducts = data.products || [];
        }
        
        if (cachedProducts.length === 0) {
            productList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">🛍️</div>
                    <div class="empty-title">No products tracked yet</div>
                    <div class="empty-subtitle">Add a product to start tracking its price</div>
                </div>
            `;
            return;
        }

        const searchLower = searchQuery.toLowerCase();
        let hasVisibleProducts = false;

        // Create or update product elements
        cachedProducts.forEach(product => {
            let element = productElements.get(product.url);
            
            if (!element) {
                element = createProductElement(product);
                productElements.set(product.url, element);
                productList.appendChild(element);
            } else {
                // Update existing element content
                updateProductElement(element, product);
            }

            // Check if product matches search
            const isVisible = !searchQuery || (
                product.title?.toLowerCase().includes(searchLower) ||
                new URL(product.url).hostname.toLowerCase().includes(searchLower) ||
                (product.currentPrice && product.currentPrice.toString().includes(searchQuery))
            );

            // Toggle visibility instead of removing/adding elements
            element.classList.toggle('hidden', !isVisible);
            if (isVisible) hasVisibleProducts = true;
        });

        // Show no results message if needed
        const emptyState = productList.querySelector('.empty-state');
        if (!hasVisibleProducts) {
            if (!emptyState) {
                productList.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-icon">🔍</div>
                        <div class="empty-title">No matching products</div>
                        <div class="empty-subtitle">Try a different search term</div>
                    </div>
                `;
            }
        } else if (emptyState) {
            emptyState.remove();
        }
    } catch (error) {
        console.error('Error updating product list:', error);
    }
}

function updateProductElement(element, product) {
    const priceInfo = element.querySelector('.price-info');
    const lastChecked = element.querySelector('.last-checked');
    const title = element.querySelector('.product-title');

    if (title) title.textContent = product.title || 'Unknown Product';
    if (priceInfo) {
        priceInfo.innerHTML = `
            <span class="current-price">${formatPrice(product.currentPrice)}</span>
            ${product.targetPrice ? `<span class="target-price">Target: ${formatPrice(product.targetPrice)}</span>` : ''}
        `;
    }
    if (lastChecked) lastChecked.textContent = `Last checked: ${formatDate(product.lastChecked)}`;
}

function createProductElement(product) {
    const li = document.createElement('li');
    li.className = 'product-item';
    li.dataset.url = product.url;
    
    const favicon = new URL(product.url).origin + '/favicon.ico';

    // Check if price is below target
    const isBelowTarget = product.targetPrice && product.currentPrice && product.currentPrice <= product.targetPrice;
    const priceClass = isBelowTarget ? 'price-below-target' : '';
    const alertIcon = isBelowTarget ? '<i class="fas fa-bell text-success"></i>' : '';
    
    // Get previous price from history
    const previousPrice = product.priceHistory && product.priceHistory.length > 1 
        ? product.priceHistory[1].price 
        : null;
    
    // Calculate price change
    let priceChangeIcon = '';
    let priceChangeClass = '';
    if (previousPrice && product.currentPrice) {
        const priceDiff = product.currentPrice - previousPrice;
        if (Math.abs(priceDiff) > 0.01) { // Only show changes greater than 1 cent
            if (priceDiff < 0) {
                priceChangeIcon = '<i class="fas fa-arrow-down text-success"></i>';
                priceChangeClass = 'price-decreased';
            } else {
                priceChangeIcon = '<i class="fas fa-arrow-up text-danger"></i>';
                priceChangeClass = 'price-increased';
            }
        }
    }
    
    li.innerHTML = `
        <div class="product-header">
            <div class="site-info">
                <img src="${favicon}" class="site-favicon" onerror="this.style.display='none'">
                <span class="site-name">${new URL(product.url).hostname}</span>
            </div>
            <button class="remove-button" data-url="${product.url}">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="product-title">${product.title || 'Unknown Product'}</div>
        <div class="product-info">
            <div class="price-info ${priceClass} ${priceChangeClass}">
                <span class="current-price">
                    ${formatPrice(product.currentPrice)} 
                    ${alertIcon} 
                    ${priceChangeIcon}
                </span>
                ${previousPrice ? `
                    <span class="price-change">
                        (${formatPriceChange(product.currentPrice - previousPrice)})
                    </span>
                ` : ''}
                ${product.targetPrice ? `<span class="target-price">Target: ${formatPrice(product.targetPrice)}</span>` : ''}
            </div>
            <div class="last-checked">Last checked: ${formatDate(product.lastChecked)}</div>
        </div>
        <div class="product-actions">
            <a href="${product.url}" target="_blank" class="view-button">
                <i class="fas fa-external-link-alt"></i> View
            </a>
            <button class="check-price-button" data-url="${product.url}">
                <i class="fas fa-sync"></i> Check Price
            </button>
        </div>
    `;
    
    // Add event listeners
    li.querySelector('.remove-button').addEventListener('click', async () => {
        if (confirm('Are you sure you want to remove this product?')) {
            try {
                const response = await chrome.runtime.sendMessage({
                    action: 'removeProduct',
                    url: product.url
                });

                if (response.success) {
                    cachedProducts = cachedProducts.filter(p => p.url !== product.url);
                    productElements.delete(product.url);
                    li.remove();
                    
                    if (cachedProducts.length === 0) {
                        updateProductList();
                    }
                    
                    showMessage('Product removed successfully!', 'success');
                }
            } catch (error) {
                console.error('Error removing product:', error);
                showMessage('Failed to remove product', 'error');
            }
        }
    });
    
    li.querySelector('.check-price-button').addEventListener('click', async (e) => {
        const button = e.currentTarget;
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-sync fa-spin"></i> Checking...';
        
        try {
            const response = await chrome.runtime.sendMessage({ 
                action: 'checkPrice', 
                url: product.url 
            });
            
            if (response.success && response.price) {
                const productIndex = cachedProducts.findIndex(p => p.url === product.url);
                if (productIndex !== -1) {
                    cachedProducts[productIndex] = {
                        ...cachedProducts[productIndex],
                        currentPrice: response.price,
                        title: response.title || cachedProducts[productIndex].title,
                        lastChecked: new Date().toISOString()
                    };
                    
                    await chrome.storage.local.set({ products: cachedProducts });
                    updateProductElement(li, cachedProducts[productIndex]);
                    showMessage('Price updated successfully!', 'success');
                }
            } else {
                showMessage(response.error || 'Could not fetch new price', 'error');
            }
        } catch (error) {
            console.error('Error checking price:', error);
            showMessage('Error updating price. Please try again.', 'error');
        } finally {
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-sync"></i> Check Price';
        }
    });
    
    return li;
}

// Format price change with sign
function formatPriceChange(change) {
    if (!change || isNaN(change)) return '';
    const sign = change > 0 ? '+' : '';
    return `${sign}${new Intl.NumberFormat('el-GR', {
        style: 'currency',
        currency: 'EUR',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(change)}`;
}

function formatPrice(price) {
    if (!price || typeof price !== 'number' || isNaN(price)) {
        return '€0.00';
    }
    return new Intl.NumberFormat('el-GR', {
        style: 'currency',
        currency: 'EUR',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(price);
}

function formatDate(date) {
    if (!date) return 'Never';
    return new Date(date).toLocaleString('el-GR', {
        day: 'numeric',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function showMessage(text, type) {
    const messageDiv = document.getElementById('message');
    messageDiv.textContent = text;
    messageDiv.className = `message ${type}`;
    
    setTimeout(() => {
        messageDiv.className = 'message';
    }, 3000);
}

// Handle search input with improved debouncing
const debounce = (fn, delay) => {
    let timeoutId;
    return (...args) => {
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
        timeoutId = setTimeout(() => {
            fn.apply(null, args);
            timeoutId = null;
        }, delay);
    };
};

function setupSearchHandler() {
    const searchInput = document.getElementById('searchInput');
    const debouncedSearch = debounce((value) => {
        requestAnimationFrame(() => {
            updateProductList(value);
        });
    }, 150);

    searchInput.addEventListener('input', (e) => {
        debouncedSearch(e.target.value.trim());
    });
}

// Handle the track button click
document.getElementById('trackButton').addEventListener('click', async () => {
    const productUrl = document.getElementById('productUrl').value;
    const targetPrice = parseFloat(document.getElementById('targetPrice').value);
    const messageDiv = document.getElementById('message');

    if (!productUrl) {
        messageDiv.textContent = 'Please enter a product URL';
        return;
    }

    // Disable the button while processing
    document.getElementById('trackButton').disabled = true;
    document.getElementById('trackButton').textContent = 'Adding...';
    messageDiv.textContent = 'Adding product...';

    try {
        const urlObject = new URL(productUrl);
        const response = await new Promise(resolve => {
            chrome.runtime.sendMessage({
                action: 'addProduct',
                url: productUrl,
                targetPrice: isNaN(targetPrice) ? null : targetPrice
            }, resolve);
        });

        if (response.success) {
            document.getElementById('productUrl').value = '';
            document.getElementById('targetPrice').value = '';
            
            // Update cached products
            const data = await chrome.storage.local.get(['products']);
            cachedProducts = data.products || [];
            await updateProductList();
            
            messageDiv.textContent = 'Product added successfully!';
        } else {
            messageDiv.textContent = response.error || 'Failed to add product.';
        }
    } catch (error) {
        messageDiv.textContent = 'Invalid URL or failed to add product.';
    } finally {
        document.getElementById('trackButton').disabled = false;
        document.getElementById('trackButton').textContent = 'Track Price';
    }
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    const productUrlInput = document.getElementById('productUrl');
    const targetPriceInput = document.getElementById('targetPrice');
    const trackButton = document.getElementById('trackButton');
    const messageDiv = document.getElementById('message');
    const productList = document.getElementById('productList');

    setupSearchHandler();
    updateProductList();
});

// Add some basic styling
const style = document.createElement('style');
style.textContent = `
    .product-info {
        margin-bottom: 10px;
    }
    .url {
        font-weight: bold;
        margin-bottom: 5px;
        word-break: break-all;
    }
    .prices {
        display: flex;
        justify-content: space-between;
        margin-bottom: 5px;
    }
    .last-checked {
        font-size: 0.8em;
        color: #666;
    }
    .check-button {
        margin-right: 5px;
    }
    .delete-button {
        color: red;
        border: none;
        background: none;
        cursor: pointer;
        font-size: 1.2em;
    }
    .price-history {
        font-size: 0.9em;
        margin-top: 5px;
    }
    .price-history ul {
        margin: 5px 0;
        padding-left: 20px;
    }
    .price-below-target {
        color: #28a745;
    }
    .price-info {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 4px;
    }
    
    .price-increased .current-price {
        color: #dc3545;
    }
    
    .price-decreased .current-price {
        color: #28a745;
    }
    
    .price-change {
        font-size: 0.9em;
        color: #6c757d;
    }
    
    .text-success {
        color: #28a745;
    }
    
    .text-danger {
        color: #dc3545;
    }
    
    .fas {
        margin: 0 4px;
    }
`;
document.head.appendChild(style);