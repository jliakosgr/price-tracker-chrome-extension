console.log('Background script loaded');

// Constants for price checking
const PRICE_CHECK_INTERVAL = 60; // minutes
const MAX_CONCURRENT_CHECKS = 3; // maximum number of concurrent price checks

// Initialize when installed
chrome.runtime.onInstalled.addListener(() => {
    console.log('Price Tracker installed');
    chrome.storage.local.get(['products'], function(data) {
        if (!data.products) {
            chrome.storage.local.set({ products: [] });
        }
    });
});

// Function to fetch price from the product page
async function fetchPrice(url) {
    console.log('Fetching price for:', url);
    
    return new Promise((resolve) => {
        try {
            // Create a hidden tab
            chrome.tabs.create({ 
                url: url, 
                active: false,
                pinned: true
            }, async (tab) => {
                if (chrome.runtime.lastError) {
                    console.error('Error creating tab:', chrome.runtime.lastError);
                    resolve(null);
                    return;
                }

                console.log('Created new hidden tab:', tab.id);
                
                try {
                    // Wait for the page to complete loading
                    await new Promise((loadResolve) => {
                        console.log('Waiting for page to load...');
                        chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
                            if (tabId === tab.id && info.status === 'complete') {
                                console.log('Page loaded completely');
                                chrome.tabs.onUpdated.removeListener(listener);
                                loadResolve();
                            }
                        });
                    });

                    // Add a small delay to ensure the page is fully rendered
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    console.log('Waiting period complete, injecting content script...');

                    // Execute content script
                    await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        files: ['content.js']
                    });
                    console.log('Content script injected');

                    // Wait a bit for the content script to initialize
                    await new Promise(resolve => setTimeout(resolve, 500));

                    // Send message to content script to get price
                    const response = await chrome.tabs.sendMessage(tab.id, { action: "getPrice" });
                    console.log('Price extraction completed, result:', response);
                    
                    // Clean up: remove the tab
                    await chrome.tabs.remove(tab.id);
                    
                    if (response && response.priceData) {
                        resolve({
                            ...response.priceData,
                            title: response.title || 'Unknown Product'
                        });
                    } else {
                        resolve(null);
                    }
                } catch (error) {
                    console.error('Error during price fetch:', error);
                    try {
                        await chrome.tabs.remove(tab.id);
                    } catch (e) {
                        console.error('Error removing tab:', e);
                    }
                    resolve(null);
                }
            });
        } catch (error) {
            console.error('Error in tab creation:', error);
            resolve(null);
        }
    });
}

// Function to normalize URL for comparison
function normalizeUrl(urlString) {
    try {
        const url = new URL(urlString);
        // Remove common tracking parameters
        const searchParams = new URLSearchParams(url.search);
        ['utm_source', 'utm_medium', 'utm_campaign', 'ref', 'fbclid'].forEach(param => {
            searchParams.delete(param);
        });
        
        // Reconstruct URL without tracking params and trailing slash
        const baseUrl = `${url.protocol}//${url.hostname}${url.pathname.replace(/\/$/, '')}`;
        const remainingParams = searchParams.toString();
        return remainingParams ? `${baseUrl}?${remainingParams}` : baseUrl;
    } catch (e) {
        console.error('Error normalizing URL:', e);
        return urlString;
    }
}

// Function to check a single product
async function checkSingleProduct(url) {
    console.log('Checking single product:', url);
    const data = await chrome.storage.local.get(['products']);
    if (data.products) {
        const updatedProducts = [...data.products];
        const productIndex = updatedProducts.findIndex(p => normalizeUrl(p.url) === normalizeUrl(url));
        
        if (productIndex !== -1) {
            const product = updatedProducts[productIndex];
            console.log('Found product:', product);
            
            const priceData = await fetchPrice(url);
            console.log('Current price data:', priceData);
            
            if (priceData !== null) {
                // Check if price is below target
                if (product.targetPrice && priceData.price <= product.targetPrice) {
                    // Show notification
                    chrome.notifications.create({
                        type: 'basic',
                        iconUrl: 'icon48.png',
                        title: 'Price Alert!',
                        message: `${product.title} is now ${priceData.price}€ - below your target of ${product.targetPrice}€!`,
                        priority: 2
                    });
                }

                updatedProducts[productIndex] = {
                    ...product,
                    currentPrice: priceData.price,
                    currency: priceData.currency || product.currency || '€',
                    lastChecked: new Date().toISOString(),
                    title: priceData.title || product.title,
                    priceHistory: [
                        {
                            price: priceData.price,
                            currency: priceData.currency || '€',
                            date: new Date().toISOString()
                        },
                        ...(product.priceHistory || []).slice(0, 29) // Keep last 30 prices
                    ]
                };
                
                await chrome.storage.local.set({ products: updatedProducts });
                return priceData;
            }
        }
    }
    return null;
}

// Function to check prices in batches
async function checkPricesInBatches(products, batchSize = MAX_CONCURRENT_CHECKS) {
    console.log(`Checking ${products.length} products in batches of ${batchSize}`);
    
    for (let i = 0; i < products.length; i += batchSize) {
        const batch = products.slice(i, i + batchSize);
        await Promise.all(batch.map(product => checkSingleProduct(product.url)));
        
        // Small delay between batches to prevent overloading
        if (i + batchSize < products.length) {
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    }
}

// Function to check all tracked products
async function checkAllPrices() {
    console.log('Starting periodic price check');
    const data = await chrome.storage.local.get(['products']);
    
    if (data.products && data.products.length > 0) {
        try {
            await checkPricesInBatches(data.products);
            console.log('Completed checking all prices');
        } catch (error) {
            console.error('Error during price check:', error);
        }
    } else {
        console.log('No products to check');
    }
}

// Initialize extension
chrome.runtime.onInstalled.addListener(() => {
    console.log('Extension installed');
    
    // Initialize storage
    chrome.storage.local.get(['products'], function(data) {
        if (!data.products) {
            chrome.storage.local.set({ products: [] });
        }
    });
    
    // Set up periodic checks using alarms
    chrome.alarms.create('checkPrices', { 
        periodInMinutes: PRICE_CHECK_INTERVAL,
        delayInMinutes: 1 // Start first check after 1 minute
    });
});

// Listen for alarm
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'checkPrices') {
        checkAllPrices();
    }
});

// Listen for messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Received message in background:', request);
    
    if (request.action === 'addProduct') {
        (async () => {
            const data = await chrome.storage.local.get(['products']);
            const products = data.products || [];
            
            const normalizedNewUrl = normalizeUrl(request.url);
            
            // Check if product already exists using normalized URLs
            if (!products.some(p => normalizeUrl(p.url) === normalizedNewUrl)) {
                const priceData = await fetchPrice(request.url);
                if (priceData !== null) {
                    products.push({
                        url: request.url,
                        title: priceData.title,
                        targetPrice: request.targetPrice,
                        currentPrice: priceData.price, // Store just the price value
                        currency: priceData.currency || '€',
                        lastChecked: new Date().toISOString(),
                        priceHistory: [{
                            price: priceData.price,
                            currency: priceData.currency || '€',
                            date: new Date().toISOString()
                        }]
                    });
                    await chrome.storage.local.set({ products });
                    sendResponse({ success: true });
                } else {
                    // If price fetch fails, add product with target price and Euro as default
                    products.push({
                        url: request.url,
                        title: 'Unknown Product',
                        targetPrice: request.targetPrice,
                        currentPrice: null,
                        currency: '€',
                        lastChecked: null,
                        priceHistory: []
                    });
                    await chrome.storage.local.set({ products });
                    sendResponse({ success: true });
                }
            } else {
                sendResponse({ success: false, error: 'Product already exists' });
            }
        })();
        return true;
    }

    if (request.action === 'checkPrice') {
        (async () => {
            try {
                const priceData = await fetchPrice(request.url);
                if (!priceData) {
                    sendResponse({ success: false, error: 'Could not fetch price' });
                    return;
                }

                // Update product in storage
                const data = await chrome.storage.local.get(['products']);
                const products = data.products || [];
                const productIndex = products.findIndex(p => normalizeUrl(p.url) === normalizeUrl(request.url));
                
                if (productIndex !== -1) {
                    products[productIndex] = {
                        ...products[productIndex],
                        title: priceData.title || products[productIndex].title,
                        currentPrice: priceData.price, // Store just the price value
                        currency: priceData.currency || products[productIndex].currency || '€',
                        lastChecked: new Date().toISOString()
                    };

                    // Add to price history
                    if (!products[productIndex].priceHistory) {
                        products[productIndex].priceHistory = [];
                    }
                    products[productIndex].priceHistory.push({
                        price: priceData.price,
                        currency: priceData.currency || '€',
                        date: new Date().toISOString()
                    });

                    await chrome.storage.local.set({ products });
                    sendResponse({ 
                        success: true, 
                        price: priceData.price,
                        currency: priceData.currency || '€',
                        title: priceData.title
                    });
                } else {
                    sendResponse({ success: false, error: 'Product not found' });
                }
            } catch (error) {
                console.error('Error checking price:', error);
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'checkPrices') {
        checkAllPrices();
        sendResponse({ status: 'checking' });
        return true;
    }

    if (request.action === 'removeProduct') {
        (async () => {
            try {
                const data = await chrome.storage.local.get(['products']);
                const products = data.products || [];
                const updatedProducts = products.filter(p => normalizeUrl(p.url) !== normalizeUrl(request.url));
                await chrome.storage.local.set({ products: updatedProducts });
                sendResponse({ success: true });
            } catch (error) {
                console.error('Error removing product:', error);
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }
});